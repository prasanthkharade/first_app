﻿(function () {


    "use strict";

    angular.module("wrapApp").service("uSrvc", ["$filter", "$rootScope", "$location", "$cookies", function ($filter, $rootScope, $location, $cookies) {
        
        this.formtCurrency = function (amount) {
            return $filter('currency')(amount, '$', 2);
        }

        //Account Utilities

        this.isUserLoggedIn = function () {

            var isAuthenticated = false;

            if ($rootScope.user != null) {
                isAuthenticated = $rootScope.user.isAuthenticated;
            }
            else {
                //Read from cookie 
                var userData = $cookies.get('userData');
                
                //console.log(userData);

                if (userData != null) {
                    $rootScope.user = angular.fromJson(userData);
                    isAuthenticated = $rootScope.user.isAuthenticated;
                }
            };

            return isAuthenticated;
        }

        this.getUserData = function () {

            var retUserData = null;

            if ($rootScope.user != null) {
                retUserData = $rootScope.user;
            }
            else {
                //Read from cookie 
                var userData = $cookies.get('userData');
                                
                if (userData != null) {
                    retUserData = angular.fromJson(userData);
                }
            };

            return retUserData;
        }

        this.getDisplayName = function () {

            var displayName = "";

            if ($rootScope.user != null)
                displayName = $rootScope.user.displayName;
            else {
                var userData = this.getUserData();
                displayName = userData.displayName;

            }

            return displayName;
        }

        this.getRole = function () {

            var roleName = "";

            if ($rootScope.user != null && $rootScope.user.roles.length > 0) {
                roleName = $rootScope.user.roles[0];
            }

            return roleName;

        }

        this.getnAccountId = function () {

            var nAccountId = "";

            if ($rootScope.user != null)
                nAccountId = $rootScope.user.nAccountID;

            return nAccountId;
        }

        this.rolesExist = function () {

            var rolesExists = false;

            if ($rootScope.user.roles.length > 0) {
                rolesExists = true;
            }

            return rolesExists;
        }

        this.isInRole = function (roleName) {
           
            var roleExists = false;
            
            var userData = this.getUserData();
            
            //debugger;
            if (userData != null && userData.roles.length > 0) {
                
               // console.log(userData.roles);

                if (userData.roles.indexOf(roleName) != -1) {
                    roleExists = true;
                }
            }

            return roleExists;
        }

        this.loginPage = function () {
            $location.path("/login");
        }

        this.logOut = function () {

            $rootScope.user = null;
        }


    }]);
})();