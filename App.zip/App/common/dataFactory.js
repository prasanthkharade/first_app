﻿
(function () {

    "use strict";

    angular.module("wrapApp").factory("df", ["$resource", "$http", function ($resource, $http) {
        
        var baseUrl = "http://localhost/wrap2/api";
                
        var df = {};

        /**Look ups **/
        df.GetStatusList = function () {
            return $resource(baseUrl + "/LookUp/GetStatusList");
        }

        df.GetReasonList = function () {
            return $resource(baseUrl + "/LookUp/GetReasonList");
        }

        df.GetGenderList = function () {
            return $resource(baseUrl + "/LookUp/GetGenderList");
        }

        df.GetMartialStatusList = function () {
            return $resource(baseUrl + "/LookUp/GetMartialStatusList");
        }

        df.GetCustomerTypes = function () {
            return $resource(baseUrl + "/LookUp/GetCustomerTypes");
        }
        
        df.GetPackages = function () {
            return $resource(baseUrl + "/LookUp/GetPackages");
        }

        df.GetRelations = function () {
            return $resource(baseUrl + "/LookUp/GetRelations");
        }

        df.GetFiscalYears = function () {
            return $resource(baseUrl + "/LookUp/GetFiscalYears");
        }
        df.GetCommitteeStatusList = function () {
            return $resource(baseUrl + "/LookUp/GetCommitteeStatusList");
        }

        df.GetCFY = function () {
            return $resource(baseUrl + "/LookUp/GetCFY");
        }
        df.getCustomerAddressInfo=function(){
            return $resource(baseUrl + "/LookUp/GetCustAddressInfo?accNo=:accNo", {accNo:"@accNo"});
        }
        df.GetCustAddrAndStatus = function () {
            return $resource(baseUrl + "/LookUp/GetCustAddrAndStatus?accNo=:accNo&cfy=:cfy", { accNo: "@accNo",cfy:"@cfy" });
        }

        /**Account**/
        df.getUserModel = function () {
            return $resource(baseUrl + "/Account/Get");
        }

        df.signIn = function (user) {
            return $http.post(baseUrl + "/Account/SignIn", user);
        }

        //Applicant        
        df.getApplicant = function () {
            return $resource(baseUrl + "/Applicant/Get/:id", {id:"@id"});
        }

        df.getApplicantDTO = function () {
            return $resource(baseUrl + "/Applicant/GetApplicantDTO/:id", { id: "@id" });
        }

        df.saveApplicant = function (data) {
            return $http.post(baseUrl + "/Applicant/Post", data);
        }

        df.deleteApplicant = function () {
            return $resource(baseUrl + "/Applicant/Delete/:id", { id: "@id" });
        }

        df.findCustomers = function () {
            return $resource(baseUrl + "/Applicant/GetCustomers?searchTerm=:sterm&fy=:fy", { sterm: "@sterm",fy:"@fy" });
        }
        
        //Packets
        df.getPacktData = function () {
            return $resource(baseUrl + "/Packet/GetPacketData?accNo=:accNo", { accNo: "@accNo"});
        }

        df.savePacket = function (data) {
            return $http.post(baseUrl + "/Packet/Post", data);
        }

        return df;

    }]);            

})();