﻿

angular.module("wrapApp").directive('validDate', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, control) {
            model.$parsers.push(function (viewValue) {
                var newDate = model.$viewValue;
                control.$setValidity("invalidDate", true);
                if (typeof newDate === "object" || newDate == "") return newDate;  // pass through if we clicked date from popup
                if (!newDate.match(/^\d{1,2}\/\d{1,2}\/((\d{2})|(\d{4}))$/))
                    control.$setValidity("invalidDate", false);
                return viewValue;
            });
        }
    };
})

/*
angular.module("wrapApp", [])
    .filter("ssn", [function () {
        return function (value) {
            if (value) {
                if (value.length >= 9) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 5) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 3) {
                    return value.substr(0, 3) + "-" + value.substr(3);
                }

            }
            return value;
        };
 }]);*/