﻿
(function () {

    "use strict";
      
    var app = angular.module("wrapApp", ["ngResource", 'ngRoute', "angular-loading-bar", 'ui.grid','ui.grid.selection', 'ngSanitize', 'ui.select', 'ui.bootstrap','ngAnimate','ngCookies','ngMask']);
    
    angular.module("wrapApp").controller("TabsDemoCtrl", ["$scope", function ($scope) {

        $scope.tabMsg = "In TabsDemoCtrl";

    }]);

    app.filter('firstChar', function () {
        return function (input) {            
            return (!!input) ? input.charAt(0).toUpperCase() : '';
        }
    });

    app.filter('fltrToUpper', function () {
        
        return function (input) {
            return (!!input) ? input.toUpperCase() : ' ';
        }
    });


    app.filter("toDate", function () {
        
    });

    app.filter('formatSSSN', function () {
        return function (value) {
            console.log(value);
            /*
            if (value) {
                if (value.length >= 9) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 5) {
                    return value.substr(0, 3) + "-" + value.substr(3, 2) + "-" + value.substr(5);
                } else if (value.length >= 3) {
                    return value.substr(0, 3) + "-" + value.substr(3);
                }
            }*/

            return value;
        }
    });


    //Routing   
    angular.module("wrapApp").config(['$routeProvider', function ($routeProvider) {
                
        $routeProvider
            .when('/landing', {
                templateUrl: 'views/landing.html',
                controller:'landingCtrl'
            })
            .when('/login', {
                templateUrl: 'views/login/login.html',
                controller: 'loginCtrl'
            })            
            .when('/report/:id', {
                templateUrl: 'views/report/report.html',
                controller: 'rptCtrl'
            })
            .when('/report/accappryr/:id', {
                templateUrl: 'views/report/accappryr.html',
                controller: 'rptCtrl'
            })
            .when('/report/fy/:id',{
                templateUrl: 'views/report/fy.html',
                controller: 'rptCtrl'
            })
            .when('/report/annualreviewnoresponse/:id', {
                templateUrl: 'views/report/annualreviewnoresponse.html',
                controller: 'rptCtrl'
            })
            .when('/report/hilowusage/:id', {
                templateUrl: 'views/report/hilowusage.html',
                controller: 'rptCtrl'
            })
            .when('/report/citynoncity/:id', {
                templateUrl: 'views/report/cityNonCity.html',
                controller: 'rptCtrl'
            })
            .when('/report/povertylevel/:id',{
                templateUrl: 'views/report/povertylevel.html',
                controller: 'rptCtrl'
            })
            .when('/letter', {
                templateUrl: 'views/reports/annualreview.html'
            }).
            when('/admin', {
                templateUrl: 'views/admin/admin.html',
                controller: 'adminCtrl'
            }).
            when('/admin/ftp/:id', {
                templateUrl: 'views/admin/ftp.html',
                controller: 'adminCtrl'
            }).
            when('/admin/hilowinfo/:id', {
                templateUrl: 'views/admin/hilowinfo.html',
                controller: 'adminCtrl'
            }).
            when('/packet', {
                templateUrl: 'views/packet/packet.html',
                controller:'packetCtrl'
            }).
             when('/packet/request', {
                 templateUrl: 'views/packet/request.html',
                 controller: 'packetCtrl'
             }).
            when('/applicant/new/:id', {
                templateUrl: 'views/applicant/new.html',
                controller: 'newApplicantCtrl'
            })            
            .otherwise({
                redirecTo: '/login'
            });
    }]);
    

})();