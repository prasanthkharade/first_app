﻿(function () {

    "use strict";

    angular.module("wrapApp").controller("newApplicantCtrl", ["$scope", "df", "$timeout", "$routeParams", "$location", "$log", "uSrvc", function ($scope, df, $timeout, $routeParams, $location, $log, uSrvc) {
        
        //Redirect to Login Page if not logged in
        if (!uSrvc.isUserLoggedIn()) {
            $location.path('/login');
        }

        //Lookup        
        $scope.lookUps = {
            statusList: {
                availableOptions: df.GetStatusList().query()                
            },
            reasonList:{
                availableOptions: df.GetReasonList().query()                
            },
            maritalStatusList: {
                availableOptions: df.GetMartialStatusList().query()
            },
            customerTypes: {
                availableOptions: df.GetCustomerTypes().query()
            },
            packages: {
                availableOptions: df.GetPackages().query()
            },
            relations: {
                availableOptions: df.GetRelations().query()
            }
        }
                
        var getApplicantData = function (_id) {

            $scope.applicant = df.getApplicant().get({ id: _id });

            if (_id == 0)
                $scope.initial = $scope.applicant;           
        }

        getApplicantData($routeParams.id);

        $scope.save = function () {
            df.saveApplicant($scope.applicant)
            .success(function (response) {
                $scope.msg = "Saved successfully.";
                //$location.path(showPage);
                console.log("Saved successfully");
            })
            .error(function (response) {
                console.log(response);
                $scope.errMsg = response;
            });
        }

        $scope.cancel = function () {
            
            $scope.errMsg = "";
            //$scope.applicant = $scope.initial;
            $scope.applicant = angular.copy($scope.initial);
        }

        //Search 

        $scope.findCustomers = function () {
            var customers = df.findCustomers().query({ sterm: '0254408000924001', fy: 'any' }, function () {
                
                $scope.customers = customers;
                $scope.gridOptions.data = customers;

                if (customers.length > 0) {
                    getApplicantData(customers[0].nappid);
                }                
            });            
        }

        $scope.gridOptions = {
            enableSorting: true,
            enableFiltering: true,
            enableRowSelection: true,
            enableRowHeaderSelection: false,
            multiSelect :false,
            modifierKeysToMultiSelect: false,
            noUnselect : true,
            columnDefs: [               
                { name: 'FY',displayName:'FY', field: 'cfy', },
                { name: 'APPLIED',displayName:'APPLIED', field: 'dappdate' },
                { name: 'ACCT#', displayName: 'ACCT#', field: 'cacctno' },
                { name: 'LAST NAME', displayName: 'LAST NAME', field: 'clastname' },
                { name: 'FIRST NAME',displayName: 'FIRST NAME', field: 'cfirstname' },
                { name: 'ADDRESS', displayName: 'ADDRESS', field: 'caddress' },
                { name: 'LAST MODIFIED', displayName: 'LAST MODIFIED', field: 'dtime' }
            ],
            data: $scope.customers
        };
                
        $scope.gridOptions.onRegisterApi = function (gridApi) {

            $scope.gridApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                getApplicantData(row.entity.nappid);

                //var msg = 'row selected ' + row.isSelected;
               // $log.log(row);
            });
        };               

    }]);

})();