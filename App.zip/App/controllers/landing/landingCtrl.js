﻿
(function(){

    "use strict";
       
    //Navigation Controller
    angular.module("wrapApp").controller("navigationCtrl", ["$scope", "df", "$location", "$rootScope", "uSrvc", "$cookies", function ($scope, df, $location, $rootScope, uSrvc, $cookies) {

        $scope.user = {
            loggedIn: false,
            userName: '',
            role: '',
            isLead: false,
            isAdmin: false,
            isRecruiter: false
        }

        $scope.loggedIn = false;
        $scope.userName = "";
        $scope.role = "";
        $scope.isLead = false;
        $scope.isAdmin = false;
        $scope.isRecruiter = false;
        $scope.invalidaAcctNo = false;
        $scope.showAccSpinner = false;

        $scope.nstatus1 = -2;

        $rootScope.$on("update", function (event, userName, isAuthenticated, role) {

            $scope.loggedIn = isAuthenticated;
            $scope.userName = userName;
            $scope.role = role;

            $scope.user.loggedIn = isAuthenticated;
            $scope.user.userName = userName;
            $scope.user.role = role;
                        
            $scope.isAdmin = uSrvc.isInRole("admins");
            $scope.isLowLife = uSrvc.isInRole("low lifes");
            $scope.isClerk = uSrvc.isInRole("Clerks");
            $scope.isAdminX = uSrvc.isInRole("adminsx");
            $scope.isCommitte = uSrvc.isInRole("Committee");
            $scope.isPacket = uSrvc.isInRole("Packets");
        });

        $rootScope.logOut = function () {

            uSrvc.logOut();

            $cookies.remove("ASPXAUTH");
            $cookies.remove("userData");

            $location.path("/login");

            $rootScope.$broadcast("update", uSrvc.getDisplayName(), uSrvc.isUserLoggedIn(), uSrvc.getRole());
        
        }
       

    }]);

    
    angular.module("wrapApp").controller("landingCtrl", ["$scope", "df", "$timeout", "$routeParams", "$location", "$log", "$rootScope", "uSrvc", "$compile", function ($scope, df, $timeout, $routeParams, $location, $log, $rootScope, uSrvc, $compile) {
                        
        $scope.searchTerm = "TROPIANO";
        $scope.searchFY = "Any";

        //Redirect to Login Page if not logged in
        if (!uSrvc.isUserLoggedIn()) {
            $location.path('/login');
        }

        $rootScope.$broadcast("update", uSrvc.getDisplayName(), uSrvc.isUserLoggedIn(), uSrvc.getRole());

        //debugger;
        $scope.isAdmin=uSrvc.isInRole("admins");

        //Lookup        
        $scope.lookUps = {
            statusList: {
                availableOptions: df.GetStatusList().query()
            },
            reasonList: {
                availableOptions: df.GetReasonList().query()
            },
            maritalStatusList: {
                availableOptions: df.GetMartialStatusList().query()
            },
            customerTypes: {
                availableOptions: df.GetCustomerTypes().query()
            },
            packages: {
                availableOptions: df.GetPackages().query()
            },
            relations: {
                availableOptions: df.GetRelations().query()
            },
            fiscalYears: {
                availableOptions: df.GetFiscalYears().query()
            },
            fiscalYear: {
                cfy: df.GetCFY().query()
            },
            committeeStatusList: {
                comStatusOptions:df.GetCommitteeStatusList().query()
            }
        }
        
        var getApplicantData = function (_id) {

            $scope.cfy = $scope.lookUps.fiscalYears.availableOptions[0];
                                    
            df.getApplicantDTO().get({ id: _id }).$promise.then(function (result) {
                $scope.applicantDto = result;

                $timeout(function ()
                {
                    $("#ddlStatus").val($scope.applicantDto.applicant.nstatus);
                    $("#ddlCommitteeStatus").val($scope.applicantDto.applicant.statcom);
                    
                }, 100);
            });
            
            if (_id != "0") {
                $scope.controlButtons("grid.row.selected");
            }
            
            if (_id == 0)
                $scope.initial = $scope.applicantDto;
        }
        
        $scope.save = function () {
            
            if ($scope.applicantDto.applicant.statcom != null || $scope.applicantDto.applicant.crejectcom != null || $scope.applicantDto.applicant.commentscom != null) {

                var name = uSrvc.getDisplayName();

                var arrNames = name.split(",");
                
                var dispName = arrNames[0];

                if (dispName.length > 16) {
                    arrNames = name.split(" ");

                    dispName = arrNames[0];
                }

                $scope.applicantDto.applicant.useridcom = dispName;
            }

            console.log($scope.applicantDto);
            
            df.saveApplicant($scope.applicantDto)
            .success(function (response) {

                $scope.msg = "Saved successfully.";

                $scope.controlButtons("init");
                $scope.defaultForm.$setPristine();

                $("#modalMessage").modal('show');                
            })
            .error(function (response) {
               // console.log(response);
                $scope.errMsg = response;
            });
        }

        $scope.cancel = function () {

            $scope.errMsg = "";            
            $scope.applicationMode = "";
            $scope.msg = "";

            $scope.controlButtons("init");

            $scope.defaultForm.$setPristine();
            
            getApplicantData(0);
        }

        $scope.delete = function () {
            df.deleteApplicant().delete(
                { id: $scope.applicantDto.applicant.nappid },
                {},
                function (returnValue, responseHeaders) {
                    $scope.msg = "Record was deleted successfully.";

                    $("#modalMessage").modal('show');

                    $scope.searchTerm = "00000";
                    $scope.findCustomers();
                    
                    $scope.showNewApplicant = true;
                },
                function (httpResponse) {
                    $scope.msg=httpResponse;
                });
        }

        $scope.newApplicant = function () {
                        
            $scope.applicationMode = "New Application";
            getApplicantData(0);
            $timeout(function ()
            {
                $scope.newFormInitData();
                $scope.controlButtons("newapplicant");
            }, 100);    

        }

        $scope.newApplicationFor = function () {

            var dCount=$scope.applicantDto.dependents.length;

            for (var i = 0; i < dCount; i++) {
                $scope.applicantDto.dependents[i].ndepid = 0;
                $scope.applicantDto.dependents[i].nappid = 0;
            }
            
            $scope.newFormInitData();
            $scope.applicationMode = "New Application For : " + $scope.applicantDto.applicant.cfirstname + " " + $scope.applicantDto.applicant.clastname;
            $scope.controlButtons("newapplicant");
        }

        $scope.addNewDependent = function () {
            var newDependent = {
                ndepid: 0,
                nappid: 0,
                clastname: '',
                cfirstname: '',
                cssno: '',
                dob: '',
                crelation: '',
                xgmi: 0.0000,
                cincsource: 'NONE',
                state:0
            };
            $scope.applicantDto.dependents.push(newDependent);
        }

        $scope.deleteDependent = function (dItem) {
            //2- Deleted
            var index = $scope.applicantDto.dependents.indexOf(dItem);

            $scope.applicantDto.dependents[index].state = 2;
            //$scope.applicantDto.dependents.splice(index, 1);

        }

        getApplicantData(0);

        //Search 
        $scope.findCustomers = function () {

            $scope.controlButtons("search");
                        
            var customers = df.findCustomers().query({ sterm: $scope.searchTerm, fy: $scope.searchFY }, function () {
                                
                $scope.customers = customers;
                $scope.gridOptions.data = customers;

                if (customers.length > 0) {
                    getApplicantData(customers[0].nappid);
                }
                else {
                    getApplicantData(0);
                }
                
                if ($scope.searchTerm == "00000") {
                    $scope.searchTerm = "";
                }
            });
        }

        $scope.getCustAddressInfo = function (accNo) {

            $scope.showAccSpinner = true;
            $scope.invalidaAcctNo = false;

            if (accNo == undefined || accNo.length == 0) {
                $scope.showAccSpinner = false;
                return;
            }
            var custInfo = df.getCustomerAddressInfo().query({ accNo: accNo }, function () {
                
                if (custInfo[0].table.length > 0) {
                                        
                    $scope.showAccSpinner = false;
                    $scope.invalidaAcctNo = false;

                    $scope.applicantDto.applicant.caddress = custInfo[0].table[0].maiL_ADDRESS1;
                    $scope.applicantDto.applicant.czip = custInfo[0].table[0].maiL_ZIP_CODE;

                    //console.log(custInfo[0].table.length);
                    //console.log(custInfo[0].table[0]);
                }
                else {
                    $scope.showAccSpinner = false;
                    $scope.invalidaAcctNo = true;                      
                }
            });

        }

        $scope.gridOptions = {
            enableSorting: true,
            enableFiltering: true,
            enableRowSelection: true,
            enableRowHeaderSelection: false,
            multiSelect: false,
            modifierKeysToMultiSelect: false,
            noUnselect: true,
            columnDefs: [
                { name: 'FY', displayName: 'FY', field: 'cfy', },
                { name: 'APPLIED', displayName: 'APPLIED', field: 'dappdate' },
                { name: 'ACCT#', displayName: 'ACCT#', field: 'cacctno' },
                { name: 'LAST NAME', displayName: 'LAST NAME', field: 'clastname' },
                { name: 'FIRST NAME', displayName: 'FIRST NAME', field: 'cfirstname' },
                { name: 'ADDRESS', displayName: 'ADDRESS', field: 'caddress' },
                { name: 'LAST MODIFIED', displayName: 'LAST MODIFIED', field: 'dtime' }
            ],
            data: $scope.customers
        };

        $scope.gridOptions.onRegisterApi = function (gridApi) {

            $scope.gridApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, function (row) {

                getApplicantData(row.entity.nappid);

                //var msg = 'row selected ' + row.isSelected;
                // $log.log(row);
            });
        };
        
        //Form Settings
        $scope.applicationMode = "";
        $scope.formMode = "";

        /*
        $scope.ShowSave = false;
        $scope.ShowCancelUndo = false;
        $scope.showNewApplicant = true;
        $scope.ShowDelete = false;
        $scope.showCreateApplicationFor = false;*/
        
        $scope.newFormInitData = function () {
                        
            $scope.formMode = "new";

            $scope.showNewApplicant = false;
            $scope.msg = "";

            var d = new Date();
            $scope.applicantDto.applicant.nappid = 0;
            $scope.applicantDto.applicant.cfy = $scope.lookUps.fiscalYear.cfy[0];
            $scope.applicantDto.applicant.dappdate = (parseInt(d.getMonth()) + 1) + "/" + d.getDate() + "/" + d.getFullYear();
            $scope.applicantDto.applicant.nstatus = "-1";
        }

        $scope.controlButtons = function (mode) {

            if (mode == "init") {

                $scope.applicationMode = "";

                $scope.disableForm = true;
                $scope.ShowSave = false;
                $scope.ShowCancelUndo = false;
                $scope.showNewApplicant = true;
                $scope.ShowDelete = false;
                $scope.showCreateApplicationFor = false;

                $scope.invalidaAcctNo = false;
                $scope.showAccSpinner = false;

                $scope.showCommitteeReview = false;
            }
            if (mode == "newapplicant") {
                $scope.disableForm = false;
                $scope.ShowSave = true;
                $scope.ShowCancelUndo = true;
                $scope.showNewApplicant = false;
                $scope.ShowDelete = false;
                //$scope.showCreateApplicationFor = false;

                $scope.showCommitteeReview = false;
            }

            if (mode == "search") {
                $scope.disableForm = true;
                $scope.ShowSave = false;
                $scope.ShowCancelUndo = false;
                $scope.showNewApplicant = true;
                $scope.ShowDelete = false;
                $scope.showCreateApplicationFor = false;
                $scope.showCommitteeReview = false;
            }

            if (mode == "grid.row.selected") {
                $scope.showCreateApplicationFor = true;
                $scope.ShowDelete = true;
                
                //debugger;
                //Temperory
                $scope.disableForm = false;
                $scope.showCommitteeReview = false;
                
                if ($scope.isAdmin && $scope.applicantDto != undefined && $scope.applicantDto.applicant.cfy == $scope.lookUps.fiscalYear.cfy[0]) {
                    $scope.showCommitteeReview = true;
                }
            }

            if (mode == "edit") {
                $scope.ShowSave = true;
                $scope.ShowCancelUndo = true;
            }

            //Apply Security

            //Maintain the order of the following statements

            if (!$scope.isAdmin) {
                $scope.disableForm = true;
            }
                        
            //Evet for Admin, allow to modify only for current fiscal year record.
            if ($scope.applicantDto != undefined && $scope.applicantDto.applicant.cfy != $scope.lookUps.fiscalYear.cfy[0]) {
                $scope.disableForm = true;
            }
        }
        $scope.committeeOKClicked = function () {
            $scope.controlButtons("edit");
        }

        $scope.controlButtons("init");

    }]);

})();