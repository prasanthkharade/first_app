﻿
(function(){

    "use strict";

    angular.module("wrapApp").controller("loginCtrl", ["$scope", "df", "$location", "$rootScope", "$cookies", function ($scope, df, $location, $rootScope, $cookies) {

        var showPage = "/landing";
        $scope.msg = "Login view";

        $scope.errMsg = "";
                
        $scope.user = df.getUserModel().get();

        $scope.user.$promise.then(function (result) {
            $scope.user.userName = "169100";
            $scope.user.password = "01159085";
        });

        $scope.signIn = function (user) {

            df.signIn(user)
            .success(function (data, status, headers, config) {
                
                $rootScope.user = data;

                //console.log($rootScope.user);

                $rootScope.password = "";
                                    
                $cookies.put('userData', angular.toJson(data));
                
                $location.path(showPage);

                $scope.msg = "";
            })
            .error(function (error) {

                user.isAuthenticated = false;
                $rootScope.user = { isAuthenticated: false };
                $scope.errMsg = error.message;

            });
        }

    }]);

})();