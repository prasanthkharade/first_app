﻿(function () {

    "use strict";

    angular.module("wrapApp").controller("adminCtrl", ["$scope", "df", "$timeout", "$routeParams", "$location", "$log", "$rootScope", "uSrvc", "$window", function ($scope, df, $timeout, $routeParams, $location, $log, $rootScope, uSrvc, $window) {

        //Redirect to Login Page if not logged in
        if (!uSrvc.isUserLoggedIn()) {
            $location.path('/login');
        }

        $rootScope.$broadcast("update", uSrvc.getDisplayName(), uSrvc.isUserLoggedIn(), uSrvc.getRole());

        $scope.rptSiteUrl = "http://localhost/WRAP2Reports/DisplayReport.aspx?";

        $scope.id = $routeParams.id;
        $scope.title = $routeParams.title;

        $scope.fdate = "";
        $scope.tdate = "";
        $scope.agYrFrom = "";
        $scope.agYrTo = "";
        $scope.fy = "";
        $scope.cityNonCity = true;
        $scope.povLevel = 0;

        /*
        $scope.showReport = function () {

            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fdate=" + $scope.fdate + "&tdate=" + $scope.tdate;

            window.open(url, '_target');
        }

        $scope.showAccountsApprovedByYear = function () {

            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fdate=" + $scope.fdate + "&tdate=" + $scope.tdate + "&fy=" + $scope.agYrFrom + "&fy2=" + $scope.agYrTo;

            window.open(url, '_target');
        }

        $scope.showFYReports = function () {
            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fy=" + $scope.fy;

            window.open(url, '_target');

        }

        $scope.annualRevNoResponse = function () {
            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fdate=" + $scope.fdate + "&tdate=" + $scope.tdate + "&fy=" + $scope.fy;
            window.open(url, '_target');
        }

        $scope.hiLowUsage = function () {
            var url = $scope.rptSiteUrl + "rid=" + $scope.id;
            window.open(url, '_target');
        }

        $scope.citynoncity = function () {

            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fdate=" + $scope.fdate + "&tdate=" + $scope.tdate + "&cfund=" + $scope.cityNonCity;

            window.open(url, '_target');
        }

        $scope.povertyLevel = function () {

            var url = $scope.rptSiteUrl + "rid=" + $scope.id + "&fdate=" + $scope.fdate + "&tdate=" + $scope.tdate + "&plevel=" + $scope.povLevel;

            window.open(url, '_target');
        }

        $scope.cancel = function () {
            $scope.fdate = "";
            $scope.tdate = "";
        }
        */

        

    }]);
})();