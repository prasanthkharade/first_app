﻿(function () {

    "use strict";

    angular.module("wrapApp").controller("packetCtrl", ["$scope", "df", "$timeout", "$routeParams", "$location", "$log", "$rootScope", "uSrvc", "$window", function ($scope, df, $timeout, $routeParams, $location, $log, $rootScope, uSrvc, $window) {

        //Redirect to Login Page if not logged in
        if (!uSrvc.isUserLoggedIn()) {
            $location.path('/login');
        }
        $rootScope.$broadcast("update", uSrvc.getDisplayName(), uSrvc.isUserLoggedIn(), uSrvc.getRole());
        
        $scope.title = $routeParams.title;
        $scope.accNo = "";

        $scope.showAccSpinner = false;
        $scope.invalidaAcctNo = false;
        $scope.address = "";
        $scope.wrapStatus = "";

        $scope.disableResendOrReceived = false;
        $scope.fourPacketSent = false;
        $scope.resendOrReceived = "";
                
        $scope.nAccountID = uSrvc.getnAccountId();
        $scope.nUsername = uSrvc.getDisplayName();

        $scope.pktReceived = false;

        //Lookup        
        $scope.lookUps = {            
            fiscalYear: {
                cfy: df.GetCFY().query()
            }
        }

        $scope.getUserInfo = function (accNo) {

            $scope.fourPacketSent = false;
            $scope.showAccSpinner = true;
            $scope.invalidaAcctNo = false;
            $scope.disableResendOrReceived = false;

            if (accNo == undefined || accNo.length == 0) {
                $scope.showAccSpinner = false;
                return;
            }
            var custInfo = df.GetCustAddrAndStatus().query({ accNo: accNo, cfy: $scope.lookUps.fiscalYear.cfy }, function () {
                
                if (custInfo[0].table.length > 0) {

                    $scope.showAccSpinner = false;
                    $scope.invalidaAcctNo = false;

                    $scope.address = custInfo[0].table[0].maiL_ADDRESS1;
                    
                    if (custInfo.length > 1 && custInfo[1].table.length > 0) {
                        $scope.wrapStatus = custInfo[1].table[0].description;
                    }
                    else {
                        $scope.wrapStatus = "NONE";
                    }

                    var packetData = df.getPacktData().query({ accNo: accNo }, function () {
                                                            
                       // debugger;

                        $scope.packet = packetData[0];
                        $scope.pktReceived = $scope.packet.bReceived;
                        
                        if ($scope.packet.packetHistory.length == 4) {
                            $scope.fourPacketSent = true;
                            $scope.packet.bReceived = "";
                        }

                        $scope.packet.nAccountID = $scope.nAccountID
                        $scope.packet.nUserName = $scope.nUsername;

                        console.log($scope.packet);

                        if ($scope.packet.packetid == 0) {
                            $scope.disableResendOrReceived = true;
                        }

                    });
                                        
                }
                else {
                    $scope.showAccSpinner = false;
                    $scope.invalidaAcctNo = true;
                }
            });
        }

        $scope.submitData = function () {
            
            $scope.errors = [];
            $scope.msg = "";

            df.savePacket($scope.packet).success(function (response) {
                
                $scope.msg = "Packet Saved successfully.";
                $scope.getUserInfo($scope.accNo);
                $("#modalMessage").modal('show');
            })
            .error(function (response) {
                                
                $scope.errors = response.modelState.error;                
                $("#modalMessage").modal('show');
            });
        }

        $scope.cancel = function () {
            $scope.packet.cust_name = "";
            $scope.packet.nHouseSize = 0;
            $scope.packet.xMonth_Income = 0;
            $scope.packet.comments = "";
        }

    }]);
})();