﻿
(function(){

    "use strict";

    //Navigation Controller
    angular.module("wrapApp").controller("navigationCtrl", ["$scope", "df", "$location", "$rootScope", "uSrvc", function ($scope, df, $location, $rootScope, uSrvc) {

        $scope.user = {
            loggedIn: false,
            userName: '',
            role: '',
            isLead: false,
            isAdmin: false,
            isRecruiter: false
        }

        $scope.loggedIn = false;
        $scope.userName = "";
        $scope.role = "";
        $scope.isLead = false;
        $scope.isAdmin = false;
        $scope.isRecruiter = false;

        $scope.summaryActive = false;
        $scope.summaryRptClick = function () {
            alert("a");
            $scope.summaryActive != $scope.summaryActive;
        }

        $rootScope.$on("update", function (event, userName, isAuthenticated, role) {

            $scope.loggedIn = isAuthenticated;
            $scope.userName = userName;
            $scope.role = role;

            $scope.isAdmin = (angular.lowercase($scope.role) == "administrator");
            $scope.isLead = (angular.lowercase($scope.role) == "lead");
            $scope.isRecruiter = (angular.lowercase($scope.role) == "recruiter");

            $scope.user.loggedIn = isAuthenticated;
            $scope.user.userName = userName;
            $scope.user.role = role;

            $scope.user.isAdmin = $scope.isAdmin;
            $scope.user.isLead = $scope.isLead;
            $scope.user.isRecruiter = $scope.isRecruiter;
        });

        $rootScope.logOut = function () {

            uSrvc.logOut();
            $location.path("/login");

            $rootScope.$broadcast("update", uSrvc.getDisplayName(), uSrvc.isUserLoggedIn(), uSrvc.getRole());
        }

    }]);

    angular.module("wrapApp").controller("leftNavigationCtrl", ["$scope", "df", "$location", "$rootScope", "uSrvc", function ($scope, df, $location, $rootScope, uSrvc) {

        $rootScope.summaryActive = false;
        $scope.summaryRptClick = function () {
            alert("a");
            $scope.summaryActive != $scope.summaryActive;
        }


    }]);

})();